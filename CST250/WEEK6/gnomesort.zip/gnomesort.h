extern void gnomesort(int n, int ar[]);
