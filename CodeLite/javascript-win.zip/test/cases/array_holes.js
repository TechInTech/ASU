var x = [,, "foo", "bar"]

var [,, y, z] = x

y //: string
z //: string
