function whoAmI(a, i) {
  a.splice(i, 1);
  a.c //+? concat, copyWithin
}
