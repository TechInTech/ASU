function Thing() {}

Element.prototype.foo = new Thing;
