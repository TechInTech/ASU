exports.a = 10;
exports.b = function() { return exports.a; };
