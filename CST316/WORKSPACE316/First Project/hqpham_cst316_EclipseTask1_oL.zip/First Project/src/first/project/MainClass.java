/**
 * 
 */
package first.project;

public class MainClass 
{
	public static void main(String[] args) 
	{
		String message = "Hello World";
		int x = 10;
		System.out.println(message + " " + x);
	}
}