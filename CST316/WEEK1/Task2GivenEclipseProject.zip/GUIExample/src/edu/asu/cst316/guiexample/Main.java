package edu.asu.cst316.guiexample;

public class Main
{
    public static void main(String args[])
    {
        new BarChartFrame(args[0]);
    }
}
