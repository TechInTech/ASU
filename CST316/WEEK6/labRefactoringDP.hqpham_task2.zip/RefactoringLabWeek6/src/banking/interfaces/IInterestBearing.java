package banking.interfaces;

//ACTIVITY 2-2 SMELL BETWEEN CLASSES <Primitive Obsession>
//public interface IInterestBearing
//{
	//public void accrueInterest();
//}
