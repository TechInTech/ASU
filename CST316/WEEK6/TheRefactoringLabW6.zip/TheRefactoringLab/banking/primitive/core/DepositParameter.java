package banking.primitive.core;

public class DepositParameter {

	public float amount;

	public DepositParameter(float amount) {
		this.amount = amount;
	}
}