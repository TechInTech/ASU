package banking.interfaces;

public interface IAsset extends java.io.Serializable {
	public void   display();
	public String getName();
}
