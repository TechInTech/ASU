package banking.interfaces;

public interface IInterestBearing
{
	public void accrueInterest();
}
