package banking.primitive.core;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@Suite.SuiteClasses({ AccountServerTest.class, CheckingTest.class })
public class AllTests {

}
