br.ufla.dcc.plugin.FanIn
========================

Eclipse plugin to identify Crosscutting Concerns using FanIn Analysis
