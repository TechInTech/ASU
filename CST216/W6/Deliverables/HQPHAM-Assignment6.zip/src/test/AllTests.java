package test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ MagicSquareTestC1C2.class, PostProcessTestC1C2C3.class })
public class AllTests {

}
